/* Щоденник студента — вебверсія. Без збірки й залежностей: один файл, ванільний JS. */
(() => {
  'use strict';

  const $ = (s, r = document) => r.querySelector(s);
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  // ───────────── сховище на пристрої ─────────────

  const LS = {
    get(k, d) { try { const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* переповнене сховище — не критично */ } },
    del(k) { try { localStorage.removeItem(k); } catch (e) { /* ignore */ } },
  };

  function makeId() {
    if (window.crypto && crypto.randomUUID) return crypto.randomUUID();
    return 'd' + Date.now().toString(36) + Math.random().toString(36).slice(2, 12);
  }
  let deviceId = LS.get('deviceId', null);
  if (!deviceId) { deviceId = makeId(); LS.set('deviceId', deviceId); }

  const DEFAULT_SETTINGS = { notificationsEnabled: true, leadMinutes: 2, askHomework: true, autoOpenLink: true, notifyHomework: true };

  const S = {
    token: LS.get('token', null),
    user: null,
    lessons: [], homework: [], subjects: {}, teachers: {}, scheduleTitle: '',
    settings: Object.assign({}, DEFAULT_SETTINGS, LS.get('settings', {})),
    answered: new Set(LS.get('answered', [])),
    done: new Set(LS.get('done', [])),
    tab: 'today',
    day: sod(new Date()),
    syncing: false, syncError: '',
    push: { supported: false, permission: 'default', subscribed: false },
    pendingRoute: null,
    pushEnsured: false,
    installEvent: null,
    needPassword: false,
    schedMsg: { text: '', cls: 'muted' },
    notify: { users: null, userId: 'all', title: '', body: '', msg: '', cls: 'muted', sending: false, err: '' },
  };

  // ───────────── дати ─────────────

  function sod(d) { const x = new Date(d); x.setHours(0, 0, 0, 0); return x; }
  function addDays(d, n) { const x = new Date(d); x.setDate(x.getDate() + n); return x; }
  function sameDay(a, b) { return a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate(); }
  const cap = (s) => s.charAt(0).toUpperCase() + s.slice(1);
  const fTime = new Intl.DateTimeFormat('uk-UA', { hour: '2-digit', minute: '2-digit', hour12: false });
  const fDM = new Intl.DateTimeFormat('uk-UA', { day: 'numeric', month: 'long' });
  const fWD = new Intl.DateTimeFormat('uk-UA', { weekday: 'long' });
  const fWS = new Intl.DateTimeFormat('uk-UA', { weekday: 'short' });
  const hm = (d) => fTime.format(d);
  const dayMonth = (d) => fDM.format(d);
  const weekdayName = (d) => cap(fWD.format(d));
  const weekdayShort = (d) => fWS.format(d).toUpperCase();
  const pad = (n) => String(n).padStart(2, '0');
  const toInput = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  const fromInput = (s) => { const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s || ''); return m ? new Date(+m[1], +m[2] - 1, +m[3]) : null; };
  const weekStart = (d) => addDays(sod(d), -((sod(d).getDay() + 6) % 7));

  // ───────────── оформлення ─────────────

  const PALETTE = ['#5865F2', '#23A559', '#EB459E', '#F0B232', '#3BA5C3', '#ED4245', '#9B84EE'];
  function subjColor(name) {
    let sum = 0;
    for (const ch of String(name)) sum = (sum + ch.codePointAt(0)) & 0xFFFF;
    return PALETTE[sum % PALETTE.length];
  }

  const ICONS = {
    bolt: '<path d="M13 2 4 14h7l-1 8 9-12h-7z"/>',
    calendar: '<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/>',
    bell: '<path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/>',
    book: '<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/>',
    gear: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/>',
    video: '<path d="M23 7l-7 5 7 5z"/><rect x="1" y="5" width="15" height="14" rx="2"/>',
    circle: '<circle cx="12" cy="12" r="10"/>',
    checkc: '<circle cx="12" cy="12" r="10" fill="currentColor" stroke="none"/><path d="M8 12.5l3 3 5-6" stroke="#fff"/>',
    clock: '<circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>',
    xc: '<circle cx="12" cy="12" r="10"/><path d="M15 9l-6 6M9 9l6 6"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    refresh: '<path d="M23 4v6h-6M1 20v-6h6"/><path d="M3.5 9a9 9 0 0 1 14.9-3.4L23 10M1 14l4.6 4.4A9 9 0 0 0 20.5 15"/>',
    left: '<path d="M15 18l-6-6 6-6"/>',
    right: '<path d="M9 18l6-6-6-6"/>',
  };
  const ic = (name, size = 22) =>
    `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONS[name] || ''}</svg>`;

  // ───────────── мережа ─────────────

  class ApiError extends Error {
    constructor(message, status, code) { super(message); this.status = status; this.code = code; }
  }

  let inflight = 0;
  let slowTimer = null;

  async function api(method, path, body) {
    const headers = { Accept: 'application/json' };
    if (body !== undefined) headers['Content-Type'] = 'application/json';
    if (S.token) headers.Authorization = 'Bearer ' + S.token;
    const ctrl = new AbortController();
    const kill = setTimeout(() => ctrl.abort(), 90000);
    if (++inflight === 1) slowTimer = setTimeout(() => { $('#banner').hidden = false; }, 6000);
    let res;
    try {
      res = await fetch(path, { method, headers, body: body !== undefined ? JSON.stringify(body) : undefined, signal: ctrl.signal });
    } catch (e) {
      throw new ApiError(e && e.name === 'AbortError'
        ? 'Сервер довго не відповідає. Спробуйте ще раз за хвилину.'
        : 'Немає зв’язку із сервером. Перевірте інтернет.', 0);
    } finally {
      clearTimeout(kill);
      if (--inflight === 0) { clearTimeout(slowTimer); $('#banner').hidden = true; }
    }
    let data = null;
    try { data = await res.json(); } catch (e) { /* порожня відповідь */ }
    if (res.status === 401 && S.token) {
      forceSignOut('Сеанс завершено. Увійдіть знову.');
      throw new ApiError('Сеанс завершено. Увійдіть знову.', 401);
    }
    if (!res.ok) throw new ApiError((data && data.error) || `Помилка сервера (${res.status}).`, res.status, data && data.code);
    return data;
  }

  // ───────────── дані ─────────────

  function applySync(r) {
    S.user = r.user;
    S.lessons = (r.lessons || []).map((l) => Object.assign({}, l, { start: new Date(l.start), end: new Date(l.end) }));
    S.subjects = r.subjects || {};
    S.teachers = r.teachers || {};
    S.scheduleTitle = r.scheduleTitle || '';
    const ids = new Set();
    S.homework = (r.homework || []).map((h) => {
      ids.add(h.id);
      return Object.assign({}, h, { due: new Date(h.due), created: new Date(h.created || Date.now()) });
    });
    S.done = new Set([...S.done].filter((id) => ids.has(id)));
    LS.set('done', [...S.done]);
  }

  async function sync() {
    if (!S.token) return;
    S.syncing = true;
    render();
    try {
      const r = await api('GET', '/api/sync');
      applySync(r);
      LS.set('cache', r);
      S.syncError = '';
      ensurePush();
    } catch (e) {
      if (e.status !== 401) S.syncError = e.message;
    } finally {
      S.syncing = false;
      render();
      processRoute();
    }
  }

  function resetLocal() {
    S.lessons = []; S.homework = []; S.subjects = {}; S.teachers = {}; S.scheduleTitle = '';
    S.answered = new Set(); S.done = new Set(); S.syncError = ''; S.pushEnsured = false;
    LS.del('cache'); LS.set('answered', []); LS.set('done', []);
  }

  async function login(fullName, password) {
    const r = await api('POST', '/api/auth/login', { fullName, deviceId, password: password || undefined });
    S.token = null;
    resetLocal();
    S.token = r.token;
    LS.set('token', r.token);
    S.user = r.user;
    S.tab = 'today';
    await sync();
  }

  let loginNotice = '';
  function forceSignOut(notice) {
    S.token = null; S.user = null;
    LS.del('token');
    resetLocal();
    closeAllSheets();
    loginNotice = notice || '';
    render();
  }

  async function signOut() {
    try {
      const sub = await getSub();
      if (sub) await api('POST', '/api/push/unsubscribe', { endpoint: sub.endpoint });
    } catch (e) { /* не критично */ }
    forceSignOut('');
  }

  // ───────────── доменна логіка ─────────────

  const isAdmin = () => !!(S.user && S.user.isAdmin);
  const lessonById = (id) => S.lessons.find((l) => l.id === id);
  const lessonsOn = (day) => S.lessons.filter((l) => sameDay(l.start, day)).sort((a, b) => a.start - b.start);
  const nextLesson = (now) => S.lessons.filter((l) => l.end > now).sort((a, b) => a.start - b.start)[0];

  const kindTitle = (l) => ({ 'Лк': 'Лекція', 'Пз': 'Практична', 'Сем': 'Семінар', '': 'Пара' }[l.kind] || l.kind);
  const placeTitle = (l) => (l.isRemote ? 'Дистанційно' : l.room ? 'ауд. ' + l.room : '—');

  function subjectKeys() {
    const set = new Set(S.lessons.map((l) => l.subjectKey));
    Object.keys(S.subjects).forEach((k) => set.add(k));
    S.homework.forEach((h) => set.add(h.subjectKey));
    return [...set].filter(Boolean).sort((a, b) => a.localeCompare(b, 'uk'));
  }
  function subjName(key) {
    const n = ((S.subjects[key] && S.subjects[key].fullName) || '').trim();
    return n || key;
  }
  function joinURL(key) {
    let s = ((S.subjects[key] && S.subjects[key].link) || '').trim();
    if (!s) return null;
    if (!s.includes('://')) s = 'https://' + s;
    try { const u = new URL(s); return /^https?:$/.test(u.protocol) ? u.toString() : null; } catch (e) { return null; }
  }
  function teacherName(raw) { const n = (S.teachers[raw] || '').trim(); return n || raw; }
  function teacherKeys() { return [...new Set(S.lessons.map((l) => l.teacher))].filter(Boolean).sort((a, b) => a.localeCompare(b, 'uk')); }

  function dueDateAfter(lesson) {
    const next = S.lessons.filter((l) => l.subjectKey === lesson.subjectKey && l.start > lesson.end).sort((a, b) => a.start - b.start)[0];
    return next ? sod(next.start) : sod(addDays(lesson.start, 1));
  }
  const newHomework = (l) => ({ id: null, subjectKey: l.subjectKey, lessonID: l.id, text: '', due: dueDateAfter(l) });
  const blankHomework = () => ({ id: null, subjectKey: subjectKeys()[0] || '', lessonID: null, text: '', due: sod(addDays(new Date(), 1)) });

  const hwDone = (h) => S.done.has(h.id);
  const listedHomework = () => S.homework.filter((h) => h.status === 'approved' || h.authorID === (S.user && S.user.id));
  const moderationQueue = () => (isAdmin() ? S.homework.filter((h) => h.status === 'pending').sort((a, b) => a.created - b.created) : []);
  const canEdit = (h) => isAdmin() || (h.authorID === (S.user && S.user.id) && h.status !== 'approved');

  function pendingPrompts() {
    const now = new Date();
    const from = new Date(now.getTime() - 24 * 3600 * 1000);
    return S.lessons.filter((l) => l.end <= now && l.end > from && !S.answered.has(l.id)).sort((a, b) => b.end - a.end);
  }

  function markAnswered(id) { S.answered.add(id); LS.set('answered', [...S.answered]); }
  function toggleDone(id) {
    if (S.done.has(id)) S.done.delete(id); else S.done.add(id);
    LS.set('done', [...S.done]);
  }
  function saveSettings() { LS.set('settings', S.settings); }

  // ───────────── шаблони ─────────────

  const card = (inner, cls = '') => `<div class="card ${cls}">${inner}</div>`;
  const badge = (text, cls = '') => `<span class="badge ${cls}">${esc(text)}</span>`;
  const hwBadge = (h) => (h.status === 'pending' ? badge('ОЧІКУЄ ПІДТВЕРДЖЕННЯ', 'warn') : h.status === 'rejected' ? badge('ВІДХИЛЕНО', 'red') : '');

  function lessonRow(l) {
    const now = new Date();
    const ongoing = l.start <= now && now < l.end;
    const finished = l.end <= now;
    return `<button class="lesson ${finished ? 'dim' : ''}" data-act="lesson" data-id="${esc(l.id)}">
      <div class="lt"><b>${hm(l.start)}</b><span>${hm(l.end)}</span></div>
      <i class="bar" style="background:${subjColor(l.subjectKey)}"></i>
      <div class="lm"><div class="ln">${esc(subjName(l.subjectKey))}</div>
        <div class="ls">${l.pair} пара · ${esc(kindTitle(l))} · ${esc(placeTitle(l))}</div></div>
      ${ongoing ? badge('ЗАРАЗ') : l.isRemote ? `<span class="muted">${ic('video', 20)}</span>` : ''}
    </button>`;
  }

  function statusText(l, now) {
    if (l.start <= now) return 'Закінчиться о ' + hm(l.end);
    const minutes = Math.floor((l.start - now) / 60000);
    if (minutes < 1) return 'Починається зараз';
    if (minutes < 60) return `Через ${minutes} хв · ${hm(l.start)}`;
    if (sameDay(l.start, now)) return 'Сьогодні о ' + hm(l.start);
    if (sameDay(l.start, addDays(now, 1))) return 'Завтра о ' + hm(l.start);
    return `${weekdayName(l.start)}, ${dayMonth(l.start)} о ${hm(l.start)}`;
  }

  function nextCard() {
    const now = new Date();
    const l = nextLesson(now);
    if (!l) return card('<div class="muted">Найближчих пар у розкладі немає. Адміністратор може завантажити новий розклад у налаштуваннях.</div>');
    const ongoing = l.start <= now;
    const url = joinURL(l.subjectKey);
    const color = subjColor(l.subjectKey);
    return card(`
      <div class="label">${ongoing ? 'Зараз іде' : 'Наступна пара'}</div>
      <div class="hstack">
        <div class="avatar" style="background:${color}38;color:${color}">${esc(l.subjectKey.charAt(0).toUpperCase())}</div>
        <div><div class="next-title">${esc(subjName(l.subjectKey))}</div>
          <div class="muted small">${esc(kindTitle(l))} · ${esc(placeTitle(l))}</div></div>
      </div>
      <div class="status ${ongoing ? 'now' : 'soon'}">${esc(statusText(l, now))}</div>
      ${l.teacher ? `<div class="muted small">${esc(teacherName(l.teacher))}</div>` : ''}
      <div class="btn-row">
        ${url ? `<a class="btn green" href="${esc(url)}" target="_blank" rel="noopener noreferrer">${ic('video', 18)} Приєднатися</a>` : ''}
        <button class="btn" data-act="lesson" data-id="${esc(l.id)}">Деталі</button>
      </div>`);
  }

  function promptCard(l) {
    return card(`
      <div class="label">Пара закінчилась о ${hm(l.end)}</div>
      <div style="font-size:17px;font-weight:600">Що задали з «${esc(subjName(l.subjectKey))}»?</div>
      <div class="btn-row">
        <button class="btn" data-act="hwNew" data-lesson="${esc(l.id)}">Записати</button>
        <button class="btn deep" data-act="answered" data-lesson="${esc(l.id)}">Нічого не задали</button>
      </div>`);
  }

  const isIOS = /iphone|ipad|ipod/i.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
  const isStandalone = () => window.navigator.standalone === true || (window.matchMedia && matchMedia('(display-mode: standalone)').matches);

  function installHint() {
    if (!(isIOS && !isStandalone()) || LS.get('hintOff', false)) return '';
    return card(`
      <div><b>Сповіщення на iPhone.</b> Відкрийте щоденник у Safari, натисніть «Поділитися» ⬆︎ → «На початковий екран» і запускайте його з іконки — лише так iOS дозволяє вебзастосункам надсилати сповіщення.</div>
      <button class="btn deep" data-act="hintOff">Зрозуміло</button>`, 'hint');
  }

  // ───────────── екрани ─────────────

  function viewToday() {
    let h = installHint();
    if (!S.lessons.length) {
      h += card(`<div class="next-title">Розкладу ще немає</div><div class="muted">${isAdmin()
        ? 'Відкрийте вкладку «Налаштування» і завантажте файл розкладу (.xls) — його одразу побачать усі студенти.'
        : 'Адміністратор ще не завантажив розклад. Зайдіть пізніше або натисніть оновлення вгорі.'}</div>`);
      return h;
    }
    h += nextCard();
    pendingPrompts().forEach((l) => { h += promptCard(l); });
    const section = (title, day) => {
      const items = lessonsOn(day);
      return `<div class="section"><div class="sec-head"><span class="label">${title}</span><span class="muted small">${dayMonth(day)}</span></div>
        ${items.length ? items.map(lessonRow).join('') : card('<span class="muted">Пар немає</span>')}</div>`;
    };
    h += section('Сьогодні', new Date()) + section('Завтра', addDays(new Date(), 1));
    return h;
  }

  function viewSchedule() {
    const start = weekStart(S.day);
    const days = [0, 1, 2, 3, 4, 5, 6].map((i) => addDays(start, i));
    const items = lessonsOn(S.day);
    return `
      <div class="weekbar">
        <button class="icon-btn" data-act="shift" data-d="-7" aria-label="Попередній тиждень">${ic('left')}</button>
        <b>${dayMonth(days[0])} – ${dayMonth(days[6])}</b>
        <button class="icon-btn" data-act="shift" data-d="7" aria-label="Наступний тиждень">${ic('right')}</button>
      </div>
      <div class="chips">${days.map((d) => `
        <button class="chip ${sameDay(d, S.day) ? 'sel' : ''} ${lessonsOn(d).length ? 'has' : ''}" data-act="day" data-ts="${d.getTime()}">
          <small>${weekdayShort(d)}</small><strong>${d.getDate()}</strong><i></i></button>`).join('')}</div>
      <div class="section"><div class="sec-head"><span class="label">${weekdayName(S.day)}</span><span class="muted small">${dayMonth(S.day)}</span></div>
        ${items.length ? items.map(lessonRow).join('') : card('<span class="muted">Пар немає</span>')}</div>`;
  }

  function hwRow(h) {
    const left = h.status === 'approved'
      ? `<button class="chk ${hwDone(h) ? 'on' : ''}" data-act="done" data-id="${esc(h.id)}" aria-label="Виконано">${ic(hwDone(h) ? 'checkc' : 'circle', 26)}</button>`
      : `<span class="chk st" style="color:${h.status === 'pending' ? 'var(--warn)' : 'var(--red)'}">${ic(h.status === 'pending' ? 'clock' : 'xc', 26)}</span>`;
    return `<div class="hw">${left}
      <button class="body" data-act="hwEdit" data-id="${esc(h.id)}">
        <div class="subj" style="color:${subjColor(h.subjectKey)}">${esc(subjName(h.subjectKey))} ${hwBadge(h)}</div>
        <div class="txt ${hwDone(h) ? 'done' : ''}">${esc(h.text)}</div>
        <div class="muted small">До ${dayMonth(h.due)}</div>
      </button></div>`;
  }

  function viewHomework() {
    const today = sod(new Date());
    const tomorrow = addDays(today, 1);
    const all = listedHomework();
    const pending = all.filter((h) => !hwDone(h));
    const overdue = pending.filter((h) => h.due < today).sort((a, b) => a.due - b.due);
    const todayItems = pending.filter((h) => sameDay(h.due, today));
    const tomorrowItems = pending.filter((h) => sameDay(h.due, tomorrow));
    const later = pending.filter((h) => h.due > tomorrow && !sameDay(h.due, tomorrow)).sort((a, b) => a.due - b.due);
    const done = all.filter(hwDone).sort((a, b) => b.due - a.due).slice(0, 15);

    const sec = (title, items) => `<div class="hw-sec"><div class="label">${title}</div>${items.map(hwRow).join('')}</div>`;
    let h = '';
    const q = moderationQueue();
    if (q.length) h += `<button class="card row" data-act="moderation" style="justify-content:space-between"><span>Чекають підтвердження</span>${badge(String(q.length), 'warn')}</button>`;
    pendingPrompts().forEach((l) => { h += promptCard(l); });
    h += `<div class="hw-sec"><div class="label">На завтра · ${dayMonth(tomorrow)}</div>${tomorrowItems.length ? tomorrowItems.map(hwRow).join('') : '<div class="muted" style="padding:10px 0">На завтра нічого не задано</div>'}</div>`;
    if (todayItems.length) h += sec('На сьогодні', todayItems);
    if (overdue.length) h += sec('Прострочено', overdue);
    if (later.length) h += sec('Пізніше', later);
    if (done.length) h += sec('Виконано', done);
    return h + `<button class="fab" data-act="hwNew" aria-label="Додати домашнє">${ic('plus', 26)}</button>`;
  }

  function viewNotify() {
    const n = S.notify;
    const opts = [`<option value="all" ${n.userId === 'all' ? 'selected' : ''}>Усім, хто увімкнув сповіщення</option>`]
      .concat((n.users || []).map((u) => `<option value="${esc(u.id)}" ${n.userId === u.id ? 'selected' : ''}>${esc(u.fullName)} ${u.pushDevices ? '🔔' + u.pushDevices : '🔕'}</option>`));
    return `
      ${card(`
        <label style="display:flex;flex-direction:column;gap:6px"><span class="label">Кому</span>
          <select class="field" data-chg="notifyField" data-key="userId" ${n.users ? '' : 'disabled'}>${opts.join('')}</select></label>
        <label style="display:flex;flex-direction:column;gap:6px"><span class="label">Заголовок (необов’язково)</span>
          <input class="field" data-inp="notifyField" data-key="title" maxlength="60" placeholder="Повідомлення від адміністратора" value="${esc(n.title)}"></label>
        <label style="display:flex;flex-direction:column;gap:6px"><span class="label">Текст</span>
          <textarea class="field" data-inp="notifyField" data-key="body" maxlength="300" rows="4" placeholder="Наприклад: завтра перша пара скасована">${esc(n.body)}</textarea></label>
        <div class="${n.cls} small" ${n.msg ? '' : 'hidden'}>${esc(n.msg)}</div>
        <button class="btn" data-act="notifySend" ${n.sending ? 'disabled' : ''}>${n.sending ? '<span class="spin"></span>' : 'Надіслати'}</button>`)}
      <div class="foot">Сповіщення прийде на всі пристрої обраної людини, де вона ввімкнула сповіщення (🔔 і число — кількість таких пристроїв, 🔕 — сповіщення не ввімкнені). Налаштування нагадувань на нього не впливають.</div>`;
  }

  async function loadNotifyUsers() {
    try {
      S.notify.users = await api('GET', '/api/admin/users');
      if (S.notify.userId !== 'all' && !S.notify.users.some((u) => u.id === S.notify.userId)) S.notify.userId = 'all';
    } catch (e) { S.notify.msg = e.message; S.notify.cls = 'err'; }
    render();
  }

  function pushStatusText() {
    const p = S.push;
    if (!p.supported) return isIOS && !isStandalone() ? 'Потрібна іконка на екрані «Додому»' : 'Не підтримується';
    if (p.permission === 'denied') return 'Заборонено';
    return p.subscribed ? 'Увімкнено на цьому пристрої' : 'Не увімкнено';
  }

  function viewSettings() {
    const st = S.settings;
    const toggle = (key, label) => `<label class="row"><span>${label}</span><span class="toggle"><input type="checkbox" data-chg="setting" data-key="${key}" ${st[key] ? 'checked' : ''}><span></span></span></label>`;
    let h = '';

    h += `<div><div class="label" style="margin:0 0 6px 4px">Акаунт</div><div class="list">
      <div class="row"><span>${esc(S.user.fullName)}</span>${isAdmin() ? badge('АДМІН', 'accent') : ''}</div>
      ${S.syncError ? `<div class="err">${esc(S.syncError)}</div>` : ''}
      <button class="row" data-act="sync"><span>Оновити дані</span></button>
      <button class="row" data-act="share"><span>Поділитися посиланням на щоденник</span></button>
      <button class="row" data-act="logout"><span style="color:var(--red)">Вийти</span></button>
    </div>${!isAdmin() ? '<div class="foot">Розклад, посилання на пари й імена викладачів налаштовує адміністратор.</div>' : ''}</div>`;

    if (isAdmin()) {
      h += `<div><div class="label" style="margin:0 0 6px 4px">Розклад</div><div class="list">
        <div>${S.lessons.length
          ? `${S.scheduleTitle ? `<div>${esc(S.scheduleTitle)}</div>` : ''}<div class="muted small">Пар у розкладі: ${S.lessons.length}${scheduleRange()}</div>`
          : '<span class="muted">Розклад не завантажено</span>'}</div>
        <label class="row" style="cursor:pointer"><span style="color:var(--accent);font-weight:600">Завантажити розклад (.xls / .xlsx / .csv)</span>
          <input type="file" id="schedFile" data-chg="schedFile" accept=".xls,.xlsx,.csv,.txt,application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,text/csv" hidden></label>
        <div id="schedMsg" class="${S.schedMsg.cls} small" ${S.schedMsg.text ? '' : 'hidden'}>${esc(S.schedMsg.text)}</div>
      </div><div class="foot">Файл розбирається у браузері й відправляється на сервер — розклад одразу побачать усі. Новий файл замінює пари від його першої дати, а домашнє й посилання лишаються.</div></div>`;

      const q = moderationQueue().length;
      h += `<div><div class="label" style="margin:0 0 6px 4px">Керування</div><div class="list">
        <button class="row" data-act="moderation"><span>Домашнє на підтвердження</span>${q ? badge(String(q), 'warn') : ''}</button>
        <button class="row" data-act="subjects"><span>Предмети й посилання</span></button>
        <button class="row" data-act="teachers"><span>Викладачі</span></button>
        <button class="row" data-act="users"><span>Учасники й пристрої</span></button>
      </div></div>`;
    }

    h += installHint();
    h += `<div><div class="label" style="margin:0 0 6px 4px">Сповіщення</div><div class="list">
      ${toggle('notificationsEnabled', 'Нагадувати про пари')}
      <div class="row"><span>За ${st.leadMinutes} хв до початку</span><span class="stepper">
        <button data-act="lead" data-d="-1" aria-label="Менше">−</button><b>${st.leadMinutes}</b><button data-act="lead" data-d="1" aria-label="Більше">+</button></span></div>
      ${toggle('askHomework', 'Питати про домашнє після пари')}
      ${toggle('notifyHomework', 'Повідомляти про нове домашнє')}
      ${toggle('autoOpenLink', 'Одразу відкривати посилання на пару')}
      <div class="row"><span>Сповіщення на цьому пристрої</span><span class="${S.push.permission === 'denied' ? 'err' : 'muted'} small" style="text-align:right">${esc(pushStatusText())}</span></div>
      ${S.push.supported && S.push.permission !== 'denied'
        ? (S.push.subscribed
          ? '<button class="row" data-act="pushOff"><span>Вимкнути на цьому пристрої</span></button><button class="row" data-act="pushTest"><span style="color:var(--accent)">Надіслати тестове сповіщення</span></button>'
          : '<button class="row" data-act="pushOn"><span style="color:var(--accent);font-weight:600">Увімкнути сповіщення</span></button>')
        : ''}
      ${S.push.permission === 'denied' ? '<div class="muted small">Сповіщення заборонено в налаштуваннях пристрою чи браузера. Дозвольте їх там і поверніться сюди.</div>' : ''}
      ${S.installEvent ? '<button class="row" data-act="install"><span style="color:var(--accent)">Встановити застосунок</span></button>' : ''}
    </div><div class="foot">Сповіщення приходять із сервера, тому працюють, навіть коли щоденник закрито. Дозвіл і підписка — окремі для кожного пристрою.</div></div>`;
    return h;
  }

  function scheduleRange() {
    if (!S.lessons.length) return '';
    const a = S.lessons.reduce((m, l) => (l.start < m ? l.start : m), S.lessons[0].start);
    const b = S.lessons.reduce((m, l) => (l.start > m ? l.start : m), S.lessons[0].start);
    return ` · ${dayMonth(a)} – ${dayMonth(b)}`;
  }

  const TABS = [
    { id: 'today', title: 'Сьогодні', icon: 'bolt' },
    { id: 'schedule', title: 'Розклад', icon: 'calendar' },
    { id: 'homework', title: 'Домашня', icon: 'book' },
    { id: 'notify', title: 'Сповіщення', icon: 'bell', admin: true },
    { id: 'settings', title: 'Налаштування', icon: 'gear' },
  ];
  const visibleTabs = () => TABS.filter((t) => !t.admin || isAdmin());

  function render() {
    const app = $('#app');
    if (!S.user) {
      if (S.token) { app.innerHTML = '<div class="login"><div class="spin" style="margin:80px auto;width:28px;height:28px"></div></div>'; return; }
      if (!$('#loginForm')) app.innerHTML = viewLogin();
      return;
    }
    const a = document.activeElement;
    if (S.tab === 'notify' && a && a.closest && a.closest('main') && /^(INPUT|TEXTAREA|SELECT)$/.test(a.tagName)) return; // не збиваємо введення
    const y = window.scrollY;
    const views = { today: viewToday, schedule: viewSchedule, homework: viewHomework, notify: viewNotify, settings: viewSettings };
    const tabs = visibleTabs();
    const cur = tabs.find((t) => t.id === S.tab) || tabs[0];
    const q = moderationQueue().length;
    app.innerHTML = `
      <header class="topbar"><h1>${cur.title}</h1><div class="right">
        ${S.tab === 'schedule' ? '<button class="link" data-act="goToday">Сьогодні</button>' : ''}
        <button class="icon-btn ${S.syncing ? 'refreshing' : ''}" data-act="sync" aria-label="Оновити">${ic('refresh', 20)}</button>
      </div></header>
      <main class="content">${views[cur.id]()}</main>
      <nav class="tabbar"><div class="tabbar-in">${tabs.map((t) => `
        <button class="tab ${t.id === S.tab ? 'active' : ''}" data-act="tab" data-tab="${t.id}">${ic(t.icon, 22)}<span>${t.title}</span>
          ${t.id === 'homework' && q ? `<span class="dot">${q}</span>` : ''}</button>`).join('')}</div></nav>`;
    window.scrollTo(0, y);
    refreshSheets();
  }

  function viewLogin() {
    return `<div class="login">
      <img class="logo" src="/icons/icon-192.png" alt="">
      <div><h1>Щоденник студента</h1><div class="muted">Введіть прізвище, ім’я та по батькові</div></div>
      <form id="loginForm" autocomplete="on">
        <div class="card" style="gap:12px">
          <span class="label">ПІБ</span>
          <input class="field" id="fullName" name="name" type="text" autocomplete="name" autocapitalize="words" autocorrect="off" spellcheck="false" placeholder="Іваненко Іван Іванович" required>
          <div id="passWrap" ${S.needPassword ? '' : 'hidden'} style="display:${S.needPassword ? 'flex' : 'none'};flex-direction:column;gap:12px">
            <span class="label">Пароль адміністратора</span>
            <input class="field" id="adminPass" type="password" autocomplete="current-password" placeholder="Потрібен для нового пристрою">
          </div>
          <div class="muted small">Під цим ПІБ вас бачитиме адміністратор. Його закріплено за цим пристроєм.</div>
        </div>
        <div id="loginErr" class="err" style="margin:12px 0;text-align:center">${esc(loginNotice)}</div>
        <button class="btn" id="loginBtn" type="submit">Увійти</button>
      </form>
    </div>`;
  }

  // ───────────── шторки (модальні вікна) ─────────────

  const sheets = [];

  function sheetHTML(s) {
    const title = typeof s.title === 'function' ? s.title() : s.title;
    return `<div class="sheet" role="dialog" aria-modal="true">
      <div class="sh-head"><div class="side"><button class="link" data-act="closeSheet">${esc(s.closeLabel || 'Закрити')}</button></div>
        <h2>${esc(title)}</h2><div class="side r">${s.right ? s.right() : ''}</div></div>
      <div class="sh-body">${s.render()}</div></div>`;
  }

  function openSheet(s) {
    s.el = document.createElement('div');
    s.el.className = 'overlay';
    s.el.innerHTML = sheetHTML(s);
    $('#sheets').appendChild(s.el);
    sheets.push(s);
    document.body.classList.add('noscroll');
    history.pushState({ sheet: sheets.length }, '');
    return s;
  }

  function rerender(s) {
    const body = $('.sh-body', s.el);
    const keep = {};
    s.el.querySelectorAll('[name]').forEach((i) => { keep[i.name] = i.value; });
    const top = body.scrollTop;
    const title = typeof s.title === 'function' ? s.title() : s.title;
    $('h2', s.el).textContent = title;
    body.innerHTML = s.render();
    s.el.querySelectorAll('[name]').forEach((i) => { if (i.name in keep) i.value = keep[i.name]; });
    body.scrollTop = top;
  }

  function refreshSheets() {
    for (const s of sheets) {
      if (s.auto === false) continue;
      const a = document.activeElement;
      if (a && s.el.contains(a) && /^(INPUT|TEXTAREA|SELECT)$/.test(a.tagName)) continue;
      rerender(s);
    }
  }

  const closeSheet = () => { if (sheets.length) history.back(); };

  function closeAllSheets() {
    while (sheets.length) sheets.pop().el.remove();
    document.body.classList.remove('noscroll');
  }

  window.addEventListener('popstate', () => {
    if (!sheets.length) return;
    sheets.pop().el.remove();
    if (!sheets.length) document.body.classList.remove('noscroll');
  });

  const sheetOf = (el) => { const o = el.closest('.overlay'); return o ? sheets.find((s) => s.el === o) : null; };

  function openLesson(id, opts) {
    const l = lessonById(id);
    if (!l) { toast('Пару не знайдено'); return; }
    openSheet({ title: () => { const x = lessonById(id); return x ? subjName(x.subjectKey) : 'Пара'; }, render: () => lessonBody(id) });
    if (opts && opts.join && S.settings.autoOpenLink) {
      const u = joinURL(l.subjectKey);
      if (u) { try { window.open(u, '_blank', 'noopener'); } catch (e) { /* браузер міг заблокувати */ } }
    }
  }

  function lessonBody(id) {
    const l = lessonById(id);
    if (!l) return '<div class="muted">Пару не знайдено</div>';
    const url = joinURL(l.subjectKey);
    const color = subjColor(l.subjectKey);
    const items = listedHomework().filter((h) => h.lessonID === l.id);
    return `
      ${card(`
        <div class="hstack"><div class="avatar" style="background:${color}38;color:${color}">${esc(l.subjectKey.charAt(0).toUpperCase())}</div>
          <div><div class="next-title">${esc(subjName(l.subjectKey))}</div>
            <div class="muted small">${esc(kindTitle(l))}${l.topic ? ' · ' + esc(l.topic) : ''}</div></div></div>
        <hr class="sep">
        <div class="info"><span>Коли</span><span>${weekdayName(l.start)}, ${dayMonth(l.start)}</span></div>
        <div class="info"><span>Час</span><span>${hm(l.start)} – ${hm(l.end)} (${l.pair} пара)</span></div>
        <div class="info"><span>Де</span><span>${esc(placeTitle(l))}</span></div>
        ${l.teacher ? `<div class="info"><span>Викладач</span><span>${esc(teacherName(l.teacher))}</span></div>` : ''}`)}
      ${url ? `<a class="btn green big" href="${esc(url)}" target="_blank" rel="noopener noreferrer">${ic('video', 20)} Приєднатися до пари</a>` : ''}
      ${isAdmin() ? card(`
        <span class="label">Посилання на пару</span>
        <input class="field" name="link" type="url" inputmode="url" autocapitalize="none" autocorrect="off" placeholder="https://zoom.us/j/… або Meet / Teams" value="${esc((S.subjects[l.subjectKey] && S.subjects[l.subjectKey].link) || '')}">
        <div class="muted small">Посилання діє для всього предмета й одразу з’являється в усіх студентів.</div>
        <div class="muted small" data-role="msg"></div>
        <button class="btn deep" data-act="saveLink" data-key="${esc(l.subjectKey)}">Зберегти посилання</button>`) : ''}
      ${card(`
        <span class="label">Домашнє після цієї пари</span>
        ${items.length ? items.map((h) => `<div><div class="txt" style="white-space:pre-wrap">${esc(h.text)}</div>
          <div class="muted small">До ${dayMonth(h.due)} ${hwBadge(h)}</div></div>`).join('') : '<div class="muted">Нічого не записано</div>'}
        <button class="btn" data-act="hwNew" data-lesson="${esc(l.id)}">${isAdmin() ? 'Записати домашнє' : 'Запропонувати домашнє'}</button>`)}`;
  }

  function openHomeworkForm(item) {
    const editing = !!item.id && S.homework.some((h) => h.id === item.id);
    const keys = subjectKeys();
    if (item.subjectKey && !keys.includes(item.subjectKey)) keys.push(item.subjectKey);
    const cur = editing ? S.homework.find((h) => h.id === item.id) : null;
    return openSheet({
      auto: false,
      closeLabel: 'Скасувати',
      item, editing,
      title: editing ? 'Домашнє' : 'Нове домашнє',
      right: () => `<button class="link" data-act="hwSave">${editing ? 'Зберегти' : isAdmin() ? 'Додати' : 'Надіслати'}</button>`,
      render: () => `<div class="form">
        <label><span class="label">Предмет</span><select class="field" name="subject">
          ${keys.map((k) => `<option value="${esc(k)}" ${k === item.subjectKey ? 'selected' : ''}>${esc(subjName(k))}</option>`).join('')}</select></label>
        <label><span class="label">Що задали</span><textarea class="field" name="text" rows="5" placeholder="Що задали">${esc(item.text)}</textarea></label>
        <label><span class="label">Здати до</span><input class="field" type="date" name="due" value="${toInput(item.due)}"></label>
        ${!isAdmin() && !editing ? '<div class="muted small">Завдання з’явиться в усіх після того, як його підтвердить адміністратор.</div>' : ''}
        ${editing && cur && cur.status === 'rejected' ? '<div class="muted small">Адміністратор відхилив це завдання. Виправте його й надішліть знову.</div>' : ''}
        <div class="err" data-role="err"></div>
        ${!editing && item.lessonID ? `<button class="btn deep" data-act="hwNone" data-lesson="${esc(item.lessonID)}">Нічого не задали</button>` : ''}
        ${editing && canEdit(cur || item) ? '<button class="btn red" data-act="hwDelete">Видалити</button>' : ''}
      </div>`,
    });
  }

  function openModeration() {
    openSheet({
      title: 'На підтвердження',
      render: () => {
        const q = moderationQueue();
        if (!q.length) return card('<span class="muted">Немає завдань на підтвердження</span>');
        return q.map((h) => card(`
          <div class="subj" style="color:${subjColor(h.subjectKey)};font-size:12px;font-weight:700">${esc(subjName(h.subjectKey))}</div>
          <div style="white-space:pre-wrap;word-break:break-word">${esc(h.text)}</div>
          <div class="muted small">До ${dayMonth(h.due)} · додав(ла): ${esc(h.authorName)}</div>
          <div class="btn-row"><button class="btn green" data-act="approve" data-id="${esc(h.id)}">Підтвердити</button>
            <button class="btn red" data-act="reject" data-id="${esc(h.id)}">Відхилити</button></div>
          <button class="btn deep" data-act="hwEdit" data-id="${esc(h.id)}">Редагувати</button>`)).join('');
      },
    });
  }

  function openSubjects() {
    openSheet({
      auto: false,
      title: 'Предмети',
      render: () => {
        const keys = subjectKeys();
        if (!keys.length) return card('<span class="muted">Спочатку завантажте розклад</span>');
        return keys.map((k) => {
          const info = S.subjects[k] || {};
          return card(`<span class="label">${esc(k)}</span>
            <input class="field" name="name" placeholder="Повна назва" value="${esc(info.fullName || '')}">
            <input class="field" name="link" type="url" inputmode="url" autocapitalize="none" autocorrect="off" placeholder="Посилання на пару (Zoom / Meet / Teams)" value="${esc(info.link || '')}">
            <div class="muted small" data-role="msg"></div>
            <button class="btn deep" data-act="saveSubject" data-key="${esc(k)}">Зберегти</button>`);
        }).join('');
      },
    });
  }

  function openTeachers() {
    openSheet({
      auto: false,
      title: 'Викладачі',
      render: () => {
        const keys = teacherKeys();
        if (!keys.length) return card('<span class="muted">У розкладі немає викладачів. Спочатку завантажте розклад.</span>');
        return keys.map((k) => card(`<span class="label">У розкладі: ${esc(k)}</span>
          <input class="field" name="name" placeholder="Прізвище Ім’я По батькові" autocapitalize="words" value="${esc(S.teachers[k] || '')}">
          <div class="muted small" data-role="msg"></div>
          <button class="btn deep" data-act="saveTeacher" data-key="${esc(k)}">Зберегти</button>`)).join('');
      },
    });
  }

  function openUsers() {
    const s = { auto: false, title: 'Учасники', users: null, err: '' };
    s.render = () => {
      if (s.err) return `<div class="err">${esc(s.err)}</div>`;
      if (!s.users) return '<div class="muted">Завантаження…</div>';
      return '<div class="muted small">Якщо людина втратила телефон чи перевстановила застосунок — натисніть «Відв’язати пристрій», і вона зможе увійти знову.</div>' +
        s.users.map((u) => card(`
          <div style="display:flex;justify-content:space-between;gap:8px"><b>${esc(u.fullName)}</b>${u.isAdmin ? badge('АДМІН', 'accent') : ''}</div>
          <div class="muted small">Пристроїв: ${u.devices}</div>
          <div class="btn-row"><button class="btn deep" data-act="resetDevices" data-id="${esc(u.id)}">Відв’язати пристрій</button>
            ${u.id !== S.user.id ? `<button class="btn red" data-act="deleteUser" data-id="${esc(u.id)}" data-name="${esc(u.fullName)}">Видалити</button>` : ''}</div>`)).join('');
    };
    s.reload = async () => {
      try { s.users = await api('GET', '/api/admin/users'); s.err = ''; } catch (e) { s.err = e.message; }
      if (sheets.includes(s)) rerender(s);
    };
    openSheet(s);
    s.reload();
  }

  // ───────────── сповіщення ─────────────

  const pushSupported = () => 'serviceWorker' in navigator && 'PushManager' in window && 'Notification' in window;

  async function getSub() {
    if (!pushSupported()) return null;
    const reg = await navigator.serviceWorker.ready;
    return reg.pushManager.getSubscription();
  }

  function b64ToU8(b64) {
    const pad = '='.repeat((4 - (b64.length % 4)) % 4);
    const raw = atob((b64 + pad).replace(/-/g, '+').replace(/_/g, '/'));
    return Uint8Array.from(raw, (c) => c.charCodeAt(0));
  }

  const pushSettings = () => ({
    notificationsEnabled: S.settings.notificationsEnabled, leadMinutes: S.settings.leadMinutes,
    askHomework: S.settings.askHomework, notifyHomework: S.settings.notifyHomework,
  });

  async function refreshPushState() {
    S.push.supported = pushSupported();
    S.push.permission = 'Notification' in window ? Notification.permission : 'denied';
    try { S.push.subscribed = !!(await getSub()); } catch (e) { S.push.subscribed = false; }
    if (S.user && S.tab === 'settings') render();
  }

  async function subscribePush() {
    const reg = await navigator.serviceWorker.ready;
    const cfg = await api('GET', '/api/push/config');
    let sub = await reg.pushManager.getSubscription();
    if (!sub) sub = await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: b64ToU8(cfg.publicKey) });
    await api('POST', '/api/push/subscribe', { subscription: sub.toJSON(), settings: pushSettings() });
    return sub;
  }

  /** Якщо дозвіл уже є — тихо прив’язуємо підписку цього пристрою до поточного користувача. */
  async function ensurePush() {
    if (S.pushEnsured || !S.token || !pushSupported() || Notification.permission !== 'granted') { refreshPushState(); return; }
    S.pushEnsured = true;
    try { await subscribePush(); } catch (e) { /* не критично */ }
    refreshPushState();
  }

  async function enablePush() {
    if (!pushSupported()) {
      toast(isIOS && !isStandalone()
        ? 'На iPhone спершу додайте щоденник на екран «Додому» і відкрийте його з іконки.'
        : 'Цей браузер не підтримує сповіщення.');
      return;
    }
    const perm = await Notification.requestPermission();
    if (perm !== 'granted') { toast('Дозвіл не надано. Його можна змінити в налаштуваннях пристрою.'); refreshPushState(); return; }
    try {
      await subscribePush();
      S.settings.notificationsEnabled = true;
      saveSettings();
      toast('Сповіщення увімкнено');
    } catch (e) {
      toast('Не вдалося увімкнути: ' + e.message);
    }
    refreshPushState();
  }

  async function disablePush() {
    try {
      const sub = await getSub();
      if (sub) {
        await api('POST', '/api/push/unsubscribe', { endpoint: sub.endpoint }).catch(() => {});
        await sub.unsubscribe();
      }
    } catch (e) { /* ignore */ }
    refreshPushState();
  }

  let settingsTimer = null;
  function pushSettingsChanged() {
    clearTimeout(settingsTimer);
    settingsTimer = setTimeout(async () => {
      try {
        const sub = await getSub();
        if (sub) await api('PUT', '/api/push/settings', { endpoint: sub.endpoint, settings: pushSettings() });
      } catch (e) { /* підтягнеться під час наступного входу */ }
    }, 500);
  }

  // ───────────── імпорт розкладу ─────────────

  let xlsxPromise = null;
  function loadXLSX() {
    if (window.XLSX) return Promise.resolve();
    if (!xlsxPromise) {
      xlsxPromise = new Promise((resolve, reject) => {
        const s = document.createElement('script');
        s.src = 'https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js';
        s.onload = resolve;
        s.onerror = () => { xlsxPromise = null; reject(new Error('Не вдалося завантажити бібліотеку для .xls. Перевірте інтернет або використайте .csv.')); };
        document.head.appendChild(s);
      });
    }
    return xlsxPromise;
  }

  function cellText(cell) {
    if (!cell) return '';
    if (cell.t === 'd' && cell.v instanceof Date) {
      const d = cell.v;
      return `${pad(d.getUTCDate())}.${pad(d.getUTCMonth() + 1)}.${d.getUTCFullYear()}`;
    }
    if (cell.t === 'n') {
      if (window.XLSX && cell.z && XLSX.SSF.is_date(cell.z)) {
        const p = XLSX.SSF.parse_date_code(cell.v);
        if (p) return `${pad(p.d)}.${pad(p.m)}.${p.y}`;
      }
      return String(cell.v);
    }
    return String(cell.v == null ? '' : cell.v);
  }

  async function readGrid(file) {
    const buf = await file.arrayBuffer();
    const b = new Uint8Array(buf);
    const ole = b[0] === 0xD0 && b[1] === 0xCF && b[2] === 0x11 && b[3] === 0xE0;
    const zip = b[0] === 0x50 && b[1] === 0x4B;
    if (!ole && !zip) return ScheduleParser.readCSV(buf);
    await loadXLSX();
    const wb = XLSX.read(buf, { type: 'array' });
    const ws = wb.Sheets[wb.SheetNames[0]];
    if (!ws || !ws['!ref']) throw new Error('Не вдалося прочитати файл. Схоже, він пошкоджений.');
    const range = XLSX.utils.decode_range(ws['!ref']);
    const grid = [];
    for (let r = range.s.r; r <= range.e.r; r++) {
      const row = [];
      for (let c = range.s.c; c <= range.e.c; c++) row.push(cellText(ws[XLSX.utils.encode_cell({ r, c })]));
      grid.push(row);
    }
    return grid;
  }

  async function importSchedule(file) {
    const say = (text, cls) => {
      S.schedMsg = { text, cls: cls || 'muted' };
      const m = $('#schedMsg');
      if (m) { m.hidden = !text; m.className = S.schedMsg.cls + ' small'; m.textContent = text; }
    };
    try {
      say('Читаю файл…');
      const parsed = ScheduleParser.parse(await readGrid(file));
      say(`Відправляю пар: ${parsed.lessons.length}…`);
      await api('PUT', '/api/schedule', { title: parsed.title, lessons: parsed.lessons });
      await sync();
      say(`Готово. Додано пар: ${parsed.lessons.length}`, 'ok');
    } catch (e) {
      say(e.message || 'Не вдалося завантажити розклад.', 'err');
    }
  }

  // ───────────── дії ─────────────

  let toastTimer = null;
  function toast(text) {
    const t = $('#toast');
    t.textContent = text;
    t.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { t.hidden = true; }, 3500);
  }

  function setMsg(root, text, cls) {
    const m = root.querySelector('[data-role="msg"]') || root;
    m.textContent = text;
    m.className = (cls || 'muted') + ' small';
    if (m.dataset) m.dataset.role = 'msg';
  }

  async function withBusy(btn, fn) {
    if (btn) btn.disabled = true;
    try { return await fn(); } finally { if (btn) btn.disabled = false; }
  }

  const ACT = {
    tab(el) { S.tab = el.dataset.tab; window.scrollTo(0, 0); render(); if (S.tab === 'notify') loadNotifyUsers(); },
    sync() { sync(); },
    lesson(el) { openLesson(el.dataset.id); },
    day(el) { S.day = sod(new Date(+el.dataset.ts)); render(); },
    shift(el) { S.day = addDays(S.day, +el.dataset.d); render(); },
    goToday() { S.day = sod(new Date()); render(); },
    done(el) { toggleDone(el.dataset.id); render(); },
    answered(el) { markAnswered(el.dataset.lesson); render(); },
    hintOff() { LS.set('hintOff', true); render(); },
    moderation() { openModeration(); },
    subjects() { openSubjects(); },
    teachers() { openTeachers(); },
    users() { openUsers(); },
    closeSheet() { closeSheet(); },

    hwNew(el) {
      const l = el.dataset.lesson ? lessonById(el.dataset.lesson) : null;
      openHomeworkForm(l ? newHomework(l) : blankHomework());
    },
    hwEdit(el) {
      const h = S.homework.find((x) => x.id === el.dataset.id);
      if (h && canEdit(h)) openHomeworkForm(Object.assign({}, h));
    },
    hwNone(el) { markAnswered(el.dataset.lesson); closeSheet(); render(); },

    async hwSave(el) {
      const s = sheetOf(el);
      if (!s) return;
      const err = $('[data-role="err"]', s.el);
      const subjectKey = $('[name=subject]', s.el).value;
      const text = $('[name=text]', s.el).value.trim();
      const due = fromInput($('[name=due]', s.el).value);
      err.textContent = '';
      if (!subjectKey) { err.textContent = 'Оберіть предмет.'; return; }
      if (!text) { err.textContent = 'Опишіть, що задали.'; return; }
      if (!due) { err.textContent = 'Вкажіть дату.'; return; }
      await withBusy(el, async () => {
        try {
          const body = { subjectKey, lessonID: s.item.lessonID || null, text, due: due.toISOString() };
          if (s.editing) await api('PATCH', '/api/homework/' + encodeURIComponent(s.item.id), body);
          else await api('POST', '/api/homework', body);
          if (s.item.lessonID) markAnswered(s.item.lessonID);
          closeSheet();
          toast(!s.editing && !isAdmin() ? 'Надіслано на підтвердження адміністратору' : 'Збережено');
          await sync();
        } catch (e) { err.textContent = e.message; }
      });
    },
    async hwDelete(el) {
      const s = sheetOf(el);
      if (!s || !confirm('Видалити це завдання?')) return;
      await withBusy(el, async () => {
        try {
          await api('DELETE', '/api/homework/' + encodeURIComponent(s.item.id));
          closeSheet();
          await sync();
        } catch (e) { $('[data-role="err"]', s.el).textContent = e.message; }
      });
    },
    async approve(el) { await moderate(el, 'approve'); },
    async reject(el) { await moderate(el, 'reject'); },

    async saveLink(el) {
      const s = sheetOf(el);
      const key = el.dataset.key;
      const box = el.closest('.card');
      await withBusy(el, async () => {
        try {
          await api('PUT', '/api/subjects', { key, fullName: (S.subjects[key] && S.subjects[key].fullName) || '', link: $('[name=link]', box).value.trim() });
          await sync();
          if (s) { const m = $('[data-role="msg"]', s.el); if (m) { m.textContent = 'Збережено'; m.className = 'ok small'; } }
        } catch (e) { setMsg(box, e.message, 'err'); }
      });
    },
    async saveSubject(el) {
      const box = el.closest('.card');
      await withBusy(el, async () => {
        try {
          setMsg(box, '');
          await api('PUT', '/api/subjects', { key: el.dataset.key, fullName: $('[name=name]', box).value.trim(), link: $('[name=link]', box).value.trim() });
          await sync();
          setMsg(box, 'Збережено', 'ok');
        } catch (e) { setMsg(box, e.message, 'err'); }
      });
    },
    async saveTeacher(el) {
      const box = el.closest('.card');
      await withBusy(el, async () => {
        try {
          setMsg(box, '');
          await api('PUT', '/api/teachers', { key: el.dataset.key, fullName: $('[name=name]', box).value.trim() });
          await sync();
          setMsg(box, 'Збережено', 'ok');
        } catch (e) { setMsg(box, e.message, 'err'); }
      });
    },

    async resetDevices(el) {
      const s = sheetOf(el);
      if (!confirm('Відв’язати пристрій цього користувача?')) return;
      try { await api('POST', `/api/admin/users/${encodeURIComponent(el.dataset.id)}/reset-devices`); toast('Пристрій відв’язано'); } catch (e) { toast(e.message); }
      if (s && s.reload) s.reload();
    },
    async deleteUser(el) {
      const s = sheetOf(el);
      if (!confirm(`Видалити користувача «${el.dataset.name}»? Його внесене домашнє збережеться.`)) return;
      try { await api('DELETE', '/api/admin/users/' + encodeURIComponent(el.dataset.id)); } catch (e) { toast(e.message); }
      if (s && s.reload) s.reload();
    },

    async notifySend(el) {
      const n = S.notify;
      if (document.activeElement && document.activeElement.blur) document.activeElement.blur();
      if (!n.body.trim()) { n.msg = 'Введіть текст сповіщення.'; n.cls = 'err'; render(); return; }
      const target = n.userId === 'all' ? 'усім' : (n.users.find((u) => u.id === n.userId) || {}).fullName;
      if (!confirm(`Надіслати сповіщення: ${target}?`)) return;
      n.sending = true; n.msg = ''; render();
      try {
        const r = await api('POST', '/api/admin/notify', { userId: n.userId, title: n.title.trim(), body: n.body.trim() });
        n.msg = `Надіслано на пристроїв: ${r.sent}`; n.cls = 'ok'; n.body = '';
      } catch (e) { n.msg = e.message; n.cls = 'err'; }
      n.sending = false;
      render();
    },
    lead(el) {
      S.settings.leadMinutes = Math.min(15, Math.max(1, S.settings.leadMinutes + +el.dataset.d));
      saveSettings(); pushSettingsChanged(); render();
    },
    pushOn() { enablePush(); },
    pushOff() { disablePush(); },
    async pushTest(el) {
      await withBusy(el, async () => {
        try {
          const sub = await getSub();
          if (!sub) throw new Error('Спершу увімкніть сповіщення.');
          await api('PUT', '/api/push/settings', { endpoint: sub.endpoint, settings: pushSettings() });
          await api('POST', '/api/push/test', { endpoint: sub.endpoint });
          toast('Тест надіслано — сповіщення має прийти за кілька секунд.');
        } catch (e) { toast(e.message); }
      });
    },
    async share() {
      const url = location.origin;
      if (navigator.share) { try { await navigator.share({ title: 'Щоденник студента', text: 'Розклад, домашнє й нагадування про пари', url }); } catch (e) { /* скасовано */ } return; }
      try { await navigator.clipboard.writeText(url); toast('Посилання скопійовано'); } catch (e) { toast(url); }
    },
    async install() {
      const ev = S.installEvent;
      if (!ev) return;
      ev.prompt();
      await ev.userChoice.catch(() => {});
      S.installEvent = null;
      render();
    },
    logout() { if (confirm('Вийти з акаунта? Дані на цьому пристрої буде видалено, на сервері вони лишаться.')) signOut(); },
  };

  async function moderate(el, what) {
    await withBusy(el, async () => {
      try {
        await api('POST', `/api/homework/${encodeURIComponent(el.dataset.id)}/${what}`);
        await sync();
      } catch (e) { toast(e.message); }
    });
  }

  document.addEventListener('click', (e) => {
    const el = e.target.closest('[data-act]');
    if (!el || el.disabled) return;
    const fn = ACT[el.dataset.act];
    if (fn) { e.preventDefault(); fn(el, e); }
  });

  document.addEventListener('change', (e) => {
    const el = e.target.closest('[data-chg]');
    if (!el) return;
    if (el.dataset.chg === 'setting') {
      S.settings[el.dataset.key] = el.checked;
      saveSettings();
      pushSettingsChanged();
      if (el.dataset.key === 'notificationsEnabled' && el.checked && S.push.supported && !S.push.subscribed) enablePush();
    } else if (el.dataset.chg === 'notifyField') {
      S.notify[el.dataset.key] = el.value;
    } else if (el.dataset.chg === 'schedFile' && el.files && el.files[0]) {
      const f = el.files[0];
      el.value = '';
      importSchedule(f);
    }
  });

  document.addEventListener('input', (e) => {
    const el = e.target.closest('[data-inp]');
    if (el && el.dataset.inp === 'notifyField') S.notify[el.dataset.key] = el.value;
  });

  document.addEventListener('submit', async (e) => {
    if (e.target.id !== 'loginForm') return;
    e.preventDefault();
    const err = $('#loginErr');
    const btn = $('#loginBtn');
    const name = $('#fullName').value.replace(/\s+/g, ' ').trim();
    err.textContent = '';
    if (name.split(' ').length < 2) { err.textContent = 'Введіть прізвище, ім’я та по батькові.'; return; }
    btn.disabled = true;
    btn.innerHTML = '<span class="spin"></span>';
    try {
      loginNotice = '';
      await login(name, $('#adminPass') ? $('#adminPass').value : '');
    } catch (ex) {
      if (!S.user) {
        if (ex.code === 'password_required') {
          S.needPassword = true;
          const w = $('#passWrap');
          if (w) { w.hidden = false; w.style.display = 'flex'; }
        }
        err.textContent = ex.message;
        btn.disabled = false;
        btn.textContent = 'Увійти';
      }
    }
  });

  // ───────────── навігація зі сповіщень ─────────────

  function routeFromUrl(urlStr) {
    try { S.pendingRoute = new URL(urlStr, location.origin).search; } catch (e) { return; }
    processRoute();
  }

  function processRoute() {
    if (!S.pendingRoute || !S.user) return;
    const p = new URLSearchParams(S.pendingRoute);
    if (p.has('lesson') && !S.lessons.length) return; // дочекаємося синхронізації
    S.pendingRoute = null;
    if (history.replaceState) history.replaceState(history.state, '', location.pathname);

    if (p.has('lesson')) openLesson(p.get('lesson'), { join: p.get('join') === '1' });
    else if (p.has('homework')) { const l = lessonById(p.get('homework')); openHomeworkForm(l ? newHomework(l) : blankHomework()); }
    else if (p.has('answered')) { markAnswered(p.get('answered')); toast('Добре, відмітили'); render(); }
    else if (p.get('tab') === 'moderation') { if (isAdmin()) { S.tab = 'homework'; render(); openModeration(); } }
    else if (p.get('tab')) { S.tab = visibleTabs().some((t) => t.id === p.get('tab')) ? p.get('tab') : 'today'; render(); }
  }

  // ───────────── запуск ─────────────

  window.addEventListener('beforeinstallprompt', (e) => { e.preventDefault(); S.installEvent = e; if (S.user && S.tab === 'settings') render(); });

  function boot() {
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('/sw.js').catch(() => {});
      navigator.serviceWorker.addEventListener('message', (e) => { if (e.data && e.data.type === 'route') routeFromUrl(e.data.url); });
    }
    if (location.search) S.pendingRoute = location.search;

    if (S.token) {
      const cached = LS.get('cache', null);
      if (cached) { try { applySync(cached); } catch (e) { /* зіпсований кеш */ } }
    }
    render();
    refreshPushState();
    if (S.token) sync();

    setInterval(() => {
      if (!S.user || sheets.length || document.hidden) return;
      if (S.tab === 'today' || S.tab === 'schedule') render();
    }, 30000);
    setInterval(() => { if (S.user && !document.hidden) sync(); }, 120000);
    document.addEventListener('visibilitychange', () => { if (!document.hidden && S.user) { sync(); refreshPushState(); } });
  }

  boot();
})();
